# Kodi

## Installing
1. Download the .zip [here](https://github.com/SIMKL/script.simkl/releases/latest)
2. Open Kodi and go to Settings > Add-ons > Install from zip file, select the zip file
3. In Settings > Add-ons > My add-ons and search for Simkl TV Tracker. Click on it.
4. Click on Configure to configure the add-on (Login and scrobbler options)
5. Please report any bugs [here](https://github.com/SIMKL/script.simkl/issues)

## TODO:
- [x] Add LICENSE.TXT
- [x] Make it work (more or less)

## Donations:
It would be very nice if you invite me for a cup of coffee:
[<img src="https://www.coinbase.com/assets/buttons/donation_large-5cf4f17cc2d2ae2f45b6b021ee498297409c94dcf0ba1bbf76fd5668e80b0d02.png">](https://www.coinbase.com/daviddavo)
Bitcoin address: 1PcbSQrBddJszsTiRhqHyLntp7Lxfuyaio

Thanks, you can write me an e-mail to david@ddavo.me with your receipt, and I'll send you a photo drinking the cup of coffee you invited me to.